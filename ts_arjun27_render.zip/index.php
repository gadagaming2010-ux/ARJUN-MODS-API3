<?php
require_once 'config.php';
$user=currentUser();
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ts-Arjun27 Mods</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,Arial;background:radial-gradient(circle at 15% 10%,#163d73 0,#07111f 35%,#030711 100%);color:#fff;min-height:100vh}.wrap{width:min(1100px,94%);margin:auto}.top{display:flex;justify-content:space-between;align-items:center;padding:22px 0}.brand{font-size:24px;font-weight:900;letter-spacing:1px}.brand b{color:#38bdf8}.pill{border:1px solid #254d76;background:#0a192b;padding:8px 13px;border-radius:999px;font-size:12px;color:#9bdcff}.card{background:rgba(8,18,32,.86);border:1px solid #1c3858;border-radius:24px;box-shadow:0 20px 70px #0008;padding:28px}.login{max-width:430px;margin:7vh auto}.h1{font-size:30px;margin:0 0 8px}.muted{color:#8da4bc}.input{width:100%;margin:10px 0;padding:14px 15px;border-radius:12px;border:1px solid #27435e;background:#06101d;color:#fff;outline:0}.input:focus{border-color:#38bdf8;box-shadow:0 0 0 3px #38bdf822}.btn{border:0;border-radius:12px;padding:13px 16px;background:linear-gradient(135deg,#22d3ee,#3b82f6);color:#03101b;font-weight:800;cursor:pointer}.btn.red{background:#ef4444;color:#fff}.btn.dark{background:#13263b;color:#dceeff}.btn:disabled{opacity:.5}.msg{margin-top:12px;padding:11px;border-radius:10px;display:none}.err{background:#451827;color:#ffb8c8}.ok{background:#103827;color:#a8ffd5}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.stat{padding:18px;border-radius:17px;background:#081727;border:1px solid #1b3a59}.stat small{color:#7892aa}.stat strong{display:block;font-size:28px;margin-top:6px}.section{margin-top:18px}.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.select,.smallinput{padding:11px;border:1px solid #27435e;background:#06101d;color:#fff;border-radius:10px}.tablewrap{overflow:auto}.table{width:100%;border-collapse:collapse;margin-top:10px}.table th,.table td{padding:11px;border-bottom:1px solid #17304a;text-align:left;font-size:13px;white-space:nowrap}.role{padding:4px 8px;border-radius:20px;background:#123451;color:#8ddaff}.hide{display:none!important}.keybox{margin-top:14px;padding:15px;background:#06131f;border:1px dashed #36d8ff;border-radius:13px;word-break:break-all;font-family:monospace}.channels{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.channel{padding:14px;background:#071625;border:1px solid #1d3a55;border-radius:14px}.channel button{margin-top:10px;width:100%}@media(max-width:750px){.grid,.channels{grid-template-columns:1fr}.top{gap:10px}.card{padding:20px}}
</style></head>
<body><div class="wrap">
<div class="top"><div class="brand">Ts-Arjun27 <b>Mods</b></div><div id="topUser" class="pill">Secure Panel</div></div>
<div id="login" class="card login">
<h1 class="h1">Welcome back</h1><p class="muted">Sign in to your secure management panel.</p>
<input id="username" class="input" placeholder="Username" autocomplete="username"><input id="password" class="input" type="password" placeholder="Password" autocomplete="current-password">
<button class="btn" style="width:100%;margin-top:8px" onclick="login()">LOGIN</button><div id="loginMsg" class="msg err"></div>
<p class="muted" style="font-size:12px;margin-top:18px">Staff access is role-based. Never share your password.</p></div>
<div id="app" class="hide">
<div class="card"><div style="display:flex;justify-content:space-between;gap:12px;align-items:center"><div><h1 id="welcome" class="h1"></h1><p id="roleText" class="muted"></p></div><button class="btn red" onclick="logout()">Logout</button></div>
<div class="grid section"><div class="stat"><small>Role</small><strong id="role">-</strong></div><div class="stat"><small>Credits</small><strong id="credits">∞</strong></div><div class="stat"><small>Key rule</small><strong>10×days</strong></div></div>
<div class="section"><h3>Generate Keys</h3><div class="row"><select id="duration" class="select"><option value="1">1 Day — 10 credits</option><option value="2">2 Days — 20 credits</option><option value="3">3 Days — 30 credits</option><option value="7">7 Days — 70 credits</option><option value="30">30 Days — 300 credits</option><option value="0">Lifetime — Super Admin only</option></select><input id="count" class="smallinput" type="number" min="1" max="100" value="1"><button class="btn" onclick="generateStaff()">Generate</button></div><div id="genMsg" class="msg"></div><div id="keysOut"></div></div>
<div id="management" class="section hide"><h3>Management</h3><div class="row"><button class="btn dark" onclick="loadUsers()">Refresh Users</button><button class="btn dark" onclick="loadKeys()">Refresh Keys</button></div><div id="createBox" class="section"></div><div id="usersOut"></div></div>
<div class="section"><h3>My Generated Keys</h3><div id="keysOut2" class="tablewrap"></div></div>
</div>
</div></div>
<script>
const api='api.php';
let me=null;
const $=id=>document.getElementById(id);
async function call(action,data={}){
 const body=new URLSearchParams({action,...data});const r=await fetch(api,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});return r.json();
}
async function login(){const r=await call('login',{username:$('username').value.trim(),password:$('password').value});if(!r.status){show('loginMsg',r.message,true);return}me=r.user;render();}
async function logout(){await call('logout');location.reload();}
function render(){ $('login').classList.add('hide');$('app').classList.remove('hide');$('welcome').textContent='Welcome '+me.username;$('roleText').textContent='Role-controlled dashboard';$('role').textContent=me.role.replace('_',' ').toUpperCase();$('credits').textContent=me.role==='super_admin'?'∞':me.credits;$('topUser').textContent=me.username+' • '+me.role;
 if(me.role!=='super_admin') [...$('duration').options].find(o=>o.value==='0').classList.add('hide');
 if(['super_admin','admin'].includes(me.role)){$('management').classList.remove('hide');$('createBox').innerHTML=`<div class="row"><input id="newUser" class="smallinput" placeholder="Username"><input id="newPass" class="smallinput" placeholder="Password"><select id="newRole" class="select">${me.role==='super_admin'?'<option value="admin">Admin</option>':''}<option value="reseller">Reseller</option></select><input id="newCredits" class="smallinput" type="number" min="0" placeholder="Credits"><button class="btn" onclick="createUser()">Create</button></div>`;loadUsers();loadKeys();}else loadKeys();}
async function generateStaff(){const r=await call('staff_generate_keys',{duration:$('duration').value,count:$('count').value});if(!r.status){show('genMsg',r.message,true);return}show('genMsg',r.message,false);$('keysOut').innerHTML='<div class="keybox">'+r.keys.join('<br>')+'</div>';me.credits=me.role==='super_admin'?me.credits:me.credits-r.credits_spent;$('credits').textContent=me.role==='super_admin'?'∞':me.credits;loadKeys();}
async function createUser(){const r=await call('admin_create_user',{username:$('newUser').value,password:$('newPass').value,role:$('newRole').value,credits:$('newCredits').value||0});alert(r.message);if(r.status)loadUsers();}
async function credit(id,mode){const a=prompt(mode==='add'?'Credits to add':'Credits to remove');if(!a)return;const r=await call('admin_credit',{user_id:id,amount:a,mode});alert(r.message);if(r.status)loadUsers();}
async function delUser(id){if(!confirm('Delete this user?'))return;const r=await call('admin_delete_user',{user_id:id});alert(r.message);loadUsers();}
async function loadUsers(){const r=await call('admin_users');if(!r.status)return;let h='<div class="tablewrap"><table class="table"><tr><th>User</th><th>Role</th><th>Credits</th><th>Actions</th></tr>';r.users.forEach(u=>{if(u.id===me.id)return;h+=`<tr><td>${esc(u.username)}</td><td><span class="role">${esc(u.role)}</span></td><td>${u.credits}</td><td><button class="btn dark" onclick="credit(${u.id},'add')">+ Credits</button> <button class="btn dark" onclick="credit(${u.id},'remove')">− Credits</button> <button class="btn red" onclick="delUser(${u.id})">Delete</button></td></tr>`});$('usersOut').innerHTML=h+'</table></div>';}
async function loadKeys(){const r=await call('admin_list_keys');if(!r.status)return;let h='<table class="table"><tr><th>Key</th><th>Days</th><th>Used</th><th>Creator</th><th>Expiry</th><th>Actions</th></tr>';r.keys.forEach(k=>{h+=`<tr><td>${esc(k.key_code)}</td><td>${k.duration_days===0?'Lifetime':k.duration_days}</td><td>${k.used?'Yes':'No'}</td><td>${esc(k.creator||'-')}</td><td>${esc(k.expires_at||'Lifetime')}</td><td><button class="btn dark" onclick="resetKey('${esc(k.key_code)}')">Reset</button> <button class="btn red" onclick="deleteKey('${esc(k.key_code)}')">Delete</button></td></tr>`});$('keysOut2').innerHTML=h+'</table>';}
async function resetKey(k){const r=await call('admin_reset_key',{key:k});alert(r.message);loadKeys();}
async function deleteKey(k){if(!confirm('Delete key?'))return;const r=await call('admin_delete_key',{key:k});alert(r.message);loadKeys();}
function show(id,msg,error){$(id).style.display='block';$(id).className='msg '+(error?'err':'ok');$(id).textContent=msg;}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
(async()=>{const r=await call('me');if(r.logged_in){me=r.user;render()}})();
</script></body></html>
