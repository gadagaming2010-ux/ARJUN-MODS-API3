<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');

function envv($key, $default = '') {
    $v = getenv($key);
    return ($v !== false && $v !== '') ? $v : $default;
}

define('DB_HOST', envv('DB_HOST', '127.0.0.1'));
define('DB_USER', envv('DB_USER', 'root'));
define('DB_PASS', envv('DB_PASS', ''));
define('DB_NAME', envv('DB_NAME', 'tsarjun27'));
define('APP_NAME', 'Ts-Arjun27 Mods');
define('GAME_NAME', envv('GAME_NAME', 'FREEFIRE'));
define('KEY_PREFIX', envv('KEY_PREFIX', 'ARJUN-MODS'));
define('JOIN_CHANNELS_REQUIRED', 3);
define('SESSION_LIFETIME', 86400);

mysqli_report(MYSQLI_REPORT_OFF);
$conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_errno) {
    http_response_code(503);
    $isApi = basename($_SERVER['SCRIPT_NAME'] ?? '') === 'api.php';
    if ($isApi) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status'=>false,'reason'=>'Database connection unavailable']);
        exit;
    }
    die('<h2>Database connection unavailable</h2><p>Set DB_HOST, DB_USER, DB_PASS and DB_NAME in Render Environment Variables.</p>');
}
$conn->set_charset('utf8mb4');

function sendJSON($data, $code=200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') exit;
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function logAPI($endpoint,$method,$requestData='',$responseData='') {
    global $conn;
    $stmt=$conn->prepare("INSERT INTO api_logs(endpoint,method,request_data,response_data,ip_address,user_agent) VALUES(?,?,?,?,?,?)");
    if ($stmt) {
        $ip=$_SERVER['REMOTE_ADDR']??'';
        $ua=$_SERVER['HTTP_USER_AGENT']??'';
        $stmt->bind_param('ssssss',$endpoint,$method,$requestData,$responseData,$ip,$ua);
        @$stmt->execute();
    }
}
function getSessionId() {
    return hash('sha256', ($_SERVER['REMOTE_ADDR']??'0.0.0.0').'|'.($_SERVER['HTTP_USER_AGENT']??'unknown').'|'.session_id());
}
function tableExists($name) {
    global $conn;
    $safe=preg_replace('/[^a-zA-Z0-9_]/','',$name);
    $r=$conn->query("SHOW TABLES LIKE '".$conn->real_escape_string($safe)."'");
    return $r && $r->num_rows > 0;
}
function initDatabase() {
    global $conn;
    $queries = [
"CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(64) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, role ENUM('super_admin','admin','reseller') NOT NULL, credits INT NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1, created_by INT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, INDEX idx_role(role), INDEX idx_created_by(created_by)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS join_tracking (id INT AUTO_INCREMENT PRIMARY KEY, session_id VARCHAR(64) NOT NULL, channel_number INT NOT NULL, channel_name VARCHAR(100), joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, verified TINYINT(1) DEFAULT 1, UNIQUE KEY unique_session_channel(session_id,channel_number)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS generated_keys (id INT AUTO_INCREMENT PRIMARY KEY, key_code VARCHAR(64) NOT NULL UNIQUE, session_id VARCHAR(64), duration_days INT DEFAULT 1, used TINYINT(1) DEFAULT 0, device_id VARCHAR(255), activated_at TIMESTAMP NULL, expires_at TIMESTAMP NULL, created_by INT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_key_code(key_code), INDEX idx_session_id(session_id), INDEX idx_used(used), INDEX idx_created_by(created_by)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS credit_transactions (id INT AUTO_INCREMENT PRIMARY KEY, from_user_id INT NULL, to_user_id INT NULL, amount INT NOT NULL, type ENUM('grant','transfer','refund','adjustment','key_spend') NOT NULL, note VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_from_user(from_user_id), INDEX idx_to_user(to_user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS api_logs (id INT AUTO_INCREMENT PRIMARY KEY, endpoint VARCHAR(100) NOT NULL, method VARCHAR(10) NOT NULL, request_data TEXT, response_data TEXT, ip_address VARCHAR(45), user_agent TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
"CREATE TABLE IF NOT EXISTS settings (id INT AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(50) NOT NULL UNIQUE, setting_value TEXT, description VARCHAR(255)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    ];
    foreach($queries as $q) @$conn->query($q);
    $defaults=[
      ['site_name','Ts-Arjun27 Mods','Website name'],
      ['game_name','FREEFIRE','Game name'],
      ['site_owner','@Ts-Arjun27','Site owner'],
      ['join_channels_required','3','Required social joins'],
      ['key_prefix','ARJUN-MODS','Key prefix'],
      ['max_devices_per_key','1','Maximum devices per key']
    ];
    foreach($defaults as $d){
        $s=$conn->prepare("INSERT IGNORE INTO settings(setting_key,setting_value,description) VALUES(?,?,?)");
        if($s){$s->bind_param('sss',$d[0],$d[1],$d[2]);@$s->execute();}
    }
    seedUser('Arjun','27','super_admin',0,null);
    seedUser('Btik','00','reseller',0,null);
}
function seedUser($username,$password,$role,$credits=0,$createdBy=null) {
    global $conn;
    $hash=password_hash($password,PASSWORD_DEFAULT);
    $s=$conn->prepare("SELECT id FROM users WHERE username=? LIMIT 1");
    if(!$s)return;
    $s->bind_param('s',$username);$s->execute();
    if($s->get_result()->num_rows===0){
        $i=$conn->prepare("INSERT INTO users(username,password_hash,role,credits,created_by) VALUES(?,?,?,?,?)");
        $i->bind_param('sssii',$username,$hash,$role,$credits,$createdBy); // corrected below by insert helper
        @$i->execute();
    }
}
function currentUser() {
    global $conn;
    if(empty($_SESSION['user_id'])) return null;
    $s=$conn->prepare("SELECT id,username,role,credits,active,created_by FROM users WHERE id=? LIMIT 1");
    $s->bind_param('i',$_SESSION['user_id']);$s->execute();
    $u=$s->get_result()->fetch_assoc();
    if(!$u || !$u['active']) { unset($_SESSION['user_id']); return null; }
    return $u;
}
function requireLogin() {
    $u=currentUser();
    if(!$u) sendJSON(['status'=>false,'message'=>'Login required'],401);
    return $u;
}
function roleRank($role){ return ['reseller'=>1,'admin'=>2,'super_admin'=>3][$role]??0; }
function canManage($actor,$targetRole){
    if($actor['role']==='super_admin') return in_array($targetRole,['admin','reseller'],true);
    if($actor['role']==='admin') return $targetRole==='reseller';
    return false;
}
function creditCost($days){ return $days===0 ? 0 : $days*10; }
function makeKey($days) {
    $type=$days===0?'LIFETIME':$days.'DAY';
    return KEY_PREFIX.'-'.$type.'-'.strtoupper(bin2hex(random_bytes(5)));
}
function getUserById($id){
    global $conn;$s=$conn->prepare("SELECT id,username,role,credits,active FROM users WHERE id=? LIMIT 1");
    $s->bind_param('i',$id);$s->execute();return $s->get_result()->fetch_assoc();
}
initDatabase();
?>