<?php
require_once 'config.php';

$action=$_POST['action']??$_GET['action']??'';
if($action==='' && (isset($_POST['user_key'])||isset($_GET['user_key'])) && (isset($_POST['serial'])||isset($_GET['serial']))) $action='connect';
logAPI('api.php?action='.$action,$_SERVER['REQUEST_METHOD'],json_encode($_POST),'');
function sessionId(){return hash('sha256',($_SERVER['REMOTE_ADDR']??'0').'|'.($_SERVER['HTTP_USER_AGENT']??'unknown').'|'.session_id());}
function requireRole($roles){
  $u=requireLogin(); if(!in_array($u['role'],$roles,true)) sendJSON(['status'=>false,'message'=>'Forbidden'],403); return $u;
}
function generateStaffKeys($actor,$days,$count){
  global $conn;
  if(!in_array($days,[1,2,3,7,30,0],true)) sendJSON(['status'=>false,'message'=>'Invalid duration'],400);
  if($days===0 && $actor['role']!=='super_admin') sendJSON(['status'=>false,'message'=>'Lifetime keys are Super Admin only'],403);
  $cost=creditCost($days)*$count;
  if($actor['role']!=='super_admin' && $actor['credits']<$cost) sendJSON(['status'=>false,'message'=>"Not enough credits. Required: {$cost}"],403);
  $keys=[];
  $conn->begin_transaction();
  try{
    for($i=0;$i<$count;$i++){
      $key=makeKey($days);
      $exp=$days===0?null:date('Y-m-d H:i:s',time()+$days*86400);
      $s=$conn->prepare("INSERT INTO generated_keys(key_code,duration_days,expires_at,created_by) VALUES(?,?,?,?)");
      $s->bind_param('sisi',$key,$days,$exp,$actor['id']);
      if(!$s->execute()) throw new Exception('Key insert failed');
      $keys[]=$key;
    }
    if($actor['role']!=='super_admin' && $cost>0){
      $s=$conn->prepare("UPDATE users SET credits=credits-? WHERE id=? AND credits>=?");
      $s->bind_param('iii',$cost,$actor['id'],$cost); if(!$s->execute()||$s->affected_rows!==1) throw new Exception('Credit update failed');
      $note="Generated {$count} x {$days}-day key(s)";
      $type='key_spend';$null=null;
      $t=$conn->prepare("INSERT INTO credit_transactions(from_user_id,to_user_id,amount,type,note) VALUES(?,?,?, ?,?)");
      $t->bind_param('iiiss',$actor['id'],$null,$cost,$type,$note);@$t->execute();
    }
    $conn->commit();
  }catch(Throwable $e){$conn->rollback();sendJSON(['status'=>false,'message'=>'Could not generate keys'],500);}
  sendJSON(['status'=>true,'message'=>count($keys).' key(s) generated','keys'=>$keys,'duration_days'=>$days,'credits_spent'=>$cost]);
}
switch($action){
case 'login':
  $u=trim($_POST['username']??'');$p=(string)($_POST['password']??'');
  if($u===''||$p==='') sendJSON(['status'=>false,'message'=>'Username and password are required'],400);
  $s=$conn->prepare("SELECT * FROM users WHERE username=? LIMIT 1");$s->bind_param('s',$u);$s->execute();$row=$s->get_result()->fetch_assoc();
  if(!$row||!$row['active']||!password_verify($p,$row['password_hash'])) sendJSON(['status'=>false,'message'=>'Invalid username or password'],401);
  session_regenerate_id(true);$_SESSION['user_id']=(int)$row['id'];
  sendJSON(['status'=>true,'user'=>['id'=>$row['id'],'username'=>$row['username'],'role'=>$row['role'],'credits'=>(int)$row['credits']]]);
case 'logout':
  $_SESSION=[];if(ini_get('session.use_cookies')){ $p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);}session_destroy();sendJSON(['status'=>true]);
case 'me':
  $u=currentUser();sendJSON(['status'=>true,'logged_in'=>(bool)$u,'user'=>$u]);
case 'staff_generate_keys':
  $u=requireLogin();$days=(int)($_POST['duration']??1);$count=max(1,min(100,(int)($_POST['count']??1)));generateStaffKeys($u,$days,$count);
case 'check_joins':
  $sid=sessionId();$s=$conn->prepare("SELECT COUNT(*) c FROM join_tracking WHERE session_id=? AND verified=1");$s->bind_param('s',$sid);$s->execute();$c=(int)$s->get_result()->fetch_assoc()['c'];sendJSON(['status'=>'success','join_count'=>$c,'required'=>3,'can_generate'=>$c>=3]);
case 'join':
  $ch=(int)($_POST['channel']??0);if($ch<1||$ch>3)sendJSON(['status'=>'error','message'=>'Invalid channel'],400);$sid=sessionId();$names=['','Telegram','YouTube','Instagram'];$s=$conn->prepare("INSERT IGNORE INTO join_tracking(session_id,channel_number,channel_name,verified) VALUES(?,?,?,1)");$s->bind_param('sis',$sid,$ch,$names[$ch]);$s->execute();sendJSON(['status'=>'success','message'=>'Channel recorded','join_count'=>(function()use($sid){global $conn;$q=$conn->prepare("SELECT COUNT(*) c FROM join_tracking WHERE session_id=? AND verified=1");$q->bind_param('s',$sid);$q->execute();return (int)$q->get_result()->fetch_assoc()['c'];})()]);
case 'generate_key':
  $sid=sessionId();$days=(int)($_POST['duration']??1);$s=$conn->prepare("SELECT COUNT(*) c FROM join_tracking WHERE session_id=? AND verified=1");$s->bind_param('s',$sid);$s->execute();if((int)$s->get_result()->fetch_assoc()['c']<3)sendJSON(['status'=>'error','message'=>'Complete all 3 channel joins first'],403);
  if(!in_array($days,[1,2,3,7,30],true))sendJSON(['status'=>'error','message'=>'Invalid duration'],400);
  $key=makeKey($days);$exp=date('Y-m-d H:i:s',time()+$days*86400);$s=$conn->prepare("INSERT INTO generated_keys(key_code,session_id,duration_days,expires_at) VALUES(?,?,?,?)");$s->bind_param('ssis',$key,$sid,$days,$exp);$s->execute();sendJSON(['status'=>'success','key'=>$key,'duration_days'=>$days,'expires_at'=>$exp]);
case 'admin_create_user':
  $actor=requireRole(['super_admin','admin']);$role=$_POST['role']??'';$username=trim($_POST['username']??'');$password=(string)($_POST['password']??'');$credits=max(0,(int)($_POST['credits']??0));
  if(!canManage($actor,$role))sendJSON(['status'=>false,'message'=>'You cannot create this role'],403);
  if(!preg_match('/^[A-Za-z0-9_]{2,32}$/',$username)||strlen($password)<2)sendJSON(['status'=>false,'message'=>'Invalid username/password'],400);
  if($actor['role']==='admin'&&$credits>$actor['credits'])sendJSON(['status'=>false,'message'=>'Not enough credits to assign'],403);
  $conn->begin_transaction();try{
    $hash=password_hash($password,PASSWORD_DEFAULT);$s=$conn->prepare("INSERT INTO users(username,password_hash,role,credits,created_by) VALUES(?,?,?,?,?)");$s->bind_param('sssii',$username,$hash,$role,$credits,$actor['id']);if(!$s->execute()) throw new Exception('duplicate');$newid=$s->insert_id;
    if($actor['role']==='admin'&&$credits>0){$s=$conn->prepare("UPDATE users SET credits=credits-? WHERE id=? AND credits>=?");$s->bind_param('iii',$credits,$actor['id'],$credits);$s->execute();if($s->affected_rows!==1)throw new Exception('credits');$type='transfer';$note='Initial reseller credits';$t=$conn->prepare("INSERT INTO credit_transactions(from_user_id,to_user_id,amount,type,note) VALUES(?,?,?,?,?)");$t->bind_param('iiiss',$actor['id'],$newid,$credits,$type,$note);$t->execute();}
    $conn->commit();
  }catch(Throwable $e){$conn->rollback();sendJSON(['status'=>false,'message'=>'Username may already exist'],400);}
  sendJSON(['status'=>true,'message'=>'User created']);
case 'admin_users':
  $actor=requireLogin();$sql=$actor['role']==='super_admin'?"SELECT id,username,role,credits,active,created_by,created_at FROM users ORDER BY id DESC":"SELECT id,username,role,credits,active,created_by,created_at FROM users WHERE created_by=? OR id=? ORDER BY id DESC";$s=$conn->prepare($sql);if($actor['role']!=='super_admin')$s->bind_param('ii',$actor['id'],$actor['id']);$s->execute();$rows=$s->get_result()->fetch_all(MYSQLI_ASSOC);sendJSON(['status'=>true,'users'=>$rows]);
case 'admin_credit':
  $actor=requireRole(['super_admin','admin']);$target=(int)($_POST['user_id']??0);$amount=(int)($_POST['amount']??0);$mode=$_POST['mode']??'add';if($amount<=0)sendJSON(['status'=>false,'message'=>'Amount must be positive'],400);$targetUser=getUserById($target);if(!$targetUser||!canManage($actor,$targetUser['role']))sendJSON(['status'=>false,'message'=>'Cannot manage this user'],403);
  if($mode==='remove'){
    if($targetUser['credits']<$amount)sendJSON(['status'=>false,'message'=>'Target does not have enough credits'],400);
    $s=$conn->prepare("UPDATE users SET credits=credits-? WHERE id=?");$s->bind_param('ii',$amount,$target);$s->execute();sendJSON(['status'=>true,'message'=>'Credits removed']);
  }
  if($actor['role']==='admin'&&$actor['credits']<$amount)sendJSON(['status'=>false,'message'=>'Not enough credits'],403);
  $conn->begin_transaction();try{
    $s=$conn->prepare("UPDATE users SET credits=credits+? WHERE id=?");$s->bind_param('ii',$amount,$target);$s->execute();
    if($actor['role']==='admin'){$s=$conn->prepare("UPDATE users SET credits=credits-? WHERE id=? AND credits>=?");$s->bind_param('iii',$amount,$actor['id'],$amount);$s->execute();if($s->affected_rows!==1)throw new Exception();}
    $type='grant';$note='Credit allocation';$t=$conn->prepare("INSERT INTO credit_transactions(from_user_id,to_user_id,amount,type,note) VALUES(?,?,?,?,?)");$from=$actor['id'];$t->bind_param('iiiss',$from,$target,$amount,$type,$note);@$t->execute();$conn->commit();
  }catch(Throwable $e){$conn->rollback();sendJSON(['status'=>false,'message'=>'Credit update failed'],500);}sendJSON(['status'=>true,'message'=>'Credits updated']);
case 'admin_delete_user':
  $actor=requireRole(['super_admin','admin']);$target=(int)($_POST['user_id']??0);$tu=getUserById($target);if(!$tu||$tu['id']===$actor['id']||!canManage($actor,$tu['role']))sendJSON(['status'=>false,'message'=>'Cannot delete this user'],403);$s=$conn->prepare("DELETE FROM users WHERE id=?");$s->bind_param('i',$target);$s->execute();sendJSON(['status'=>true,'message'=>'User deleted']);
case 'admin_list_keys':
  $actor=requireLogin();if($actor['role']==='super_admin'){$s=$conn->query("SELECT g.*,u.username creator FROM generated_keys g LEFT JOIN users u ON u.id=g.created_by ORDER BY g.created_at DESC LIMIT 500");}
  else {$s=$conn->prepare("SELECT g.*,u.username creator FROM generated_keys g LEFT JOIN users u ON u.id=g.created_by WHERE g.created_by=? OR u.created_by=? ORDER BY g.created_at DESC LIMIT 500");$s->bind_param('ii',$actor['id'],$actor['id']);$s->execute();$s=$s->get_result();}
  sendJSON(['status'=>true,'keys'=>$s->fetch_all(MYSQLI_ASSOC)]);
case 'admin_reset_key':
  $actor=requireLogin();$key=strtoupper(trim($_POST['key']??''));$s=$conn->prepare("SELECT * FROM generated_keys WHERE key_code=? LIMIT 1");$s->bind_param('s',$key);$s->execute();$row=$s->get_result()->fetch_assoc();if(!$row)sendJSON(['status'=>false,'message'=>'Key not found'],404);if($actor['role']!=='super_admin'&&(int)$row['created_by']!==$actor['id'])sendJSON(['status'=>false,'message'=>'Forbidden'],403);$d=(int)$row['duration_days'];$exp=$d===0?null:date('Y-m-d H:i:s',time()+$d*86400);$s=$conn->prepare("UPDATE generated_keys SET used=0,device_id=NULL,activated_at=NULL,expires_at=? WHERE key_code=?");$s->bind_param('ss',$exp,$key);$s->execute();sendJSON(['status'=>true,'message'=>'Key reset']);
case 'admin_delete_key':
  $actor=requireLogin();$key=strtoupper(trim($_POST['key']??''));$s=$conn->prepare("SELECT created_by FROM generated_keys WHERE key_code=?");$s->bind_param('s',$key);$s->execute();$row=$s->get_result()->fetch_assoc();if(!$row)sendJSON(['status'=>false,'message'=>'Key not found'],404);if($actor['role']!=='super_admin'&&(int)$row['created_by']!==$actor['id'])sendJSON(['status'=>false,'message'=>'Forbidden'],403);$s=$conn->prepare("DELETE FROM generated_keys WHERE key_code=?");$s->bind_param('s',$key);$s->execute();sendJSON(['status'=>true,'message'=>'Key deleted']);
case 'admin_delete_all_keys':
  requireRole(['super_admin']);$conn->query("DELETE FROM generated_keys");sendJSON(['status'=>true,'message'=>'All keys deleted']);
case 'connect':
  $licenseKey=strtoupper(trim($_POST['user_key']??$_GET['user_key']??''));$serial=trim($_POST['serial']??$_GET['serial']??'');$game=strtoupper(trim($_POST['game']??$_GET['game']??GAME_NAME));
  if($licenseKey===''||$serial==='')sendJSON(['status'=>false,'reason'=>'License key and device serial are required'],400);if($game!==GAME_NAME)sendJSON(['status'=>false,'reason'=>'Invalid game'],403);
  $s=$conn->prepare("SELECT * FROM generated_keys WHERE key_code=? LIMIT 1");$s->bind_param('s',$licenseKey);$s->execute();$k=$s->get_result()->fetch_assoc();if(!$k)sendJSON(['status'=>false,'reason'=>'Invalid license key'],404);
  if(!empty($k['expires_at'])&&strtotime($k['expires_at'])<time())sendJSON(['status'=>false,'reason'=>'License key has expired'],403);
  if(!empty($k['device_id'])&&$k['device_id']!==$serial)sendJSON(['status'=>false,'reason'=>'This key is already bound to another device'],403);
  if(empty($k['device_id'])){$s=$conn->prepare("UPDATE generated_keys SET used=1,device_id=?,activated_at=NOW() WHERE id=?");$s->bind_param('si',$serial,$k['id']);$s->execute();}
  $secret=envv('MOD_AUTH_SECRET','CHANGE_ME');$token=md5($game.'-'.$licenseKey.'-'.$serial.'-'.$secret);sendJSON(['status'=>true,'data'=>['token'=>$token,'rng'=>time(),'EXP'=>!empty($k['expires_at'])?$k['expires_at']:'Lifetime']]);
case 'verify':
  $key=strtoupper(trim($_POST['key']??$_GET['key']??''));$device=trim($_POST['device_id']??$_GET['device_id']??'');$s=$conn->prepare("SELECT * FROM generated_keys WHERE key_code=?");$s->bind_param('s',$key);$s->execute();$k=$s->get_result()->fetch_assoc();if(!$k)sendJSON(['status'=>'error','valid'=>false,'message'=>'Invalid license key'],404);
  if(!empty($k['expires_at'])&&strtotime($k['expires_at'])<time())sendJSON(['status'=>'error','valid'=>false,'message'=>'License key has expired'],403);
  if($k['used']&&$k['device_id']!==$device)sendJSON(['status'=>'error','valid'=>false,'message'=>'Device mismatch'],403);
  if(!$k['used']){if($device==='')sendJSON(['status'=>'error','valid'=>false,'message'=>'Device ID required'],400);$s=$conn->prepare("UPDATE generated_keys SET used=1,device_id=?,activated_at=NOW() WHERE id=?");$s->bind_param('si',$device,$k['id']);$s->execute();}
  $days=$k['expires_at']?max(0,(int)ceil((strtotime($k['expires_at'])-time())/86400)):null;sendJSON(['status'=>'success','valid'=>true,'key'=>$key,'expires_at'=>$k['expires_at'],'days_left'=>$days,'device_bound'=>true]);
case 'check_key':
  $key=strtoupper(trim($_POST['key']??$_GET['key']??''));$device=trim($_POST['device_id']??$_GET['device_id']??'');$s=$conn->prepare("SELECT * FROM generated_keys WHERE key_code=?");$s->bind_param('s',$key);$s->execute();$k=$s->get_result()->fetch_assoc();if(!$k)sendJSON(['status'=>'error','valid'=>false],404);$expired=!empty($k['expires_at'])&&strtotime($k['expires_at'])<time();$days=$k['expires_at']?max(0,(int)ceil((strtotime($k['expires_at'])-time())/86400)):null;sendJSON(['status'=>'success','valid'=>!$expired&&$k['used']==1,'used'=>(bool)$k['used'],'expired'=>$expired,'expires_at'=>$k['expires_at'],'days_left'=>$days,'device_bound'=>!empty($k['device_id']),'device_match'=>empty($device)?false:$k['device_id']===$device]);
case 'health':
  sendJSON(['status'=>'success','message'=>'Ts-Arjun27 Mods API is running','game'=>GAME_NAME,'database'=>$conn->ping()?'connected':'disconnected','time'=>date('c')]);
default:
  sendJSON(['status'=>'error','message'=>'Invalid action','available_actions'=>['health','connect','verify','check_key','login','staff_generate_keys']],400);
}
?>