-- Ts-Arjun27 Mods - Render MySQL schema
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('super_admin','admin','reseller') NOT NULL,
  credits INT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_role (role),
  INDEX idx_created_by (created_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS join_tracking (
  id INT AUTO_INCREMENT PRIMARY KEY,
  session_id VARCHAR(64) NOT NULL,
  channel_number INT NOT NULL,
  channel_name VARCHAR(100) DEFAULT NULL,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  verified TINYINT(1) DEFAULT 1,
  UNIQUE KEY unique_session_channel (session_id, channel_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS generated_keys (
  id INT AUTO_INCREMENT PRIMARY KEY,
  key_code VARCHAR(64) NOT NULL UNIQUE,
  session_id VARCHAR(64) DEFAULT NULL,
  duration_days INT DEFAULT 1,
  used TINYINT(1) DEFAULT 0,
  device_id VARCHAR(255) DEFAULT NULL,
  activated_at TIMESTAMP NULL,
  expires_at TIMESTAMP NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_key_code (key_code),
  INDEX idx_session_id (session_id),
  INDEX idx_used (used),
  INDEX idx_created_by (created_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS credit_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  from_user_id INT NULL,
  to_user_id INT NULL,
  amount INT NOT NULL,
  type ENUM('grant','transfer','refund','adjustment','key_spend') NOT NULL,
  note VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_from_user (from_user_id),
  INDEX idx_to_user (to_user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS api_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  endpoint VARCHAR(100) NOT NULL,
  method VARCHAR(10) NOT NULL,
  request_data TEXT,
  response_data TEXT,
  ip_address VARCHAR(45) DEFAULT NULL,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(50) NOT NULL UNIQUE,
  setting_value TEXT,
  description VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO settings (setting_key, setting_value, description) VALUES
('site_name','Ts-Arjun27 Mods','Website name'),
('game_name','FREEFIRE','Game name'),
('site_owner','@Ts-Arjun27','Site owner'),
('join_channels_required','3','Required social joins for guest generation'),
('key_prefix','ARJUN-MODS','License key prefix'),
('max_devices_per_key','1','Maximum devices per key'),
('session_lifetime','86400','Session lifetime in seconds'),
('api_rate_limit','100','API requests per hour');

-- Initial accounts are created automatically by config.php with password_hash().
-- Super Admin: Arjun / 27
-- Reseller: Btik / 00
