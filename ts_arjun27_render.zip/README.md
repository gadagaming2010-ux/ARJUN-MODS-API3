# Ts-Arjun27 Mods — Render package

## Roles
- Super Admin: Arjun / 27
- Reseller: Btik / 00
- Admins are created by Super Admin.

## Credits
1/2/3/7/30 day keys cost 10/20/30/70/300 credits.
Lifetime keys are Super Admin only and do not consume credits.

## Render architecture
Use one Docker Web Service for PHP and one MySQL service. Render's current documentation supports Docker web services and a MySQL service template. A persistent MySQL disk is required for data durability.

Do not upload `.env` or real secrets to GitHub. Set Render Environment Variables:
DB_HOST, DB_USER, DB_PASS, DB_NAME, GAME_NAME, KEY_PREFIX, ADMIN_SECRET, MOD_AUTH_SECRET, BASE_URL.

The application creates its tables automatically on first connection, and database.sql is included for manual import/inspection.

Native mod endpoint:
POST /connect
user_key=...&serial=...&game=FREEFIRE

Health:
GET /api.php?action=health
